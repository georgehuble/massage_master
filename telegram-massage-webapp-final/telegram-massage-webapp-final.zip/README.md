# Telegram Massage WebApp

Готово к деплою на Vercel.